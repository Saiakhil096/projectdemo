var express = require('express');
var router = express.Router();
const item = require('../model/item');

router.get('/', (req, res) => {
    console.log('am from different router module');
});

router.post('/item', (req, res, next) => {
    const newitem = new item(
        {
            name:req.body.name,
            quantity:req.body.quantity,
            itembought:req.body.itembought
        });//item close

newitem.save((err, item) => {
    if (err) {
        res.json(err);
    }
    else {
        res.json({ msg: 'insterted' });
    }
});
});
router.get('/item',(req, res)=> {
    item.find().then (items=> {
 
      res.send(items);
    });
  });
router.delete('/item/:id', (req, res, next) =>{
    item.remove({_id:req.params.id},
        function(err,result){
        if(err){
            res.json(err);
        }
        else{
            res.json(result);
        }
    });
  });

  router.get('/item/:id', function (req, res) {
    item.findById(req.params.id,(err,data)=>{
if(err){
res.json(err)
}
else{
    res.json(data)

}
    })
 
});

  router.put("/item/:id",(req,res,next)=>{
    item.findOneAndUpdate({_id:req.params.id},{
        $set:{
        name:req.body.name,
        quantity:req.body.quantity,
        itembought:req.body.itembought
    }
},function(err,result){
        if(err){
            res.json(err);
        }
        else{
            res.json({ msg: 'Item has been updated successfully'})
        }
    })

  })


module.exports = router;
